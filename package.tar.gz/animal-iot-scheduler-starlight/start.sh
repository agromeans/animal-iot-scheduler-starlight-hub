#/bin/bash
pip3 --disable-pip-version-check install wait-for-it==2.2.0

cd agromeans
wait-for-it \
--service localhost:5080 \
--service localhost:5081 \
--service localhost:5084 \
--service localhost:5085 \
--service localhost:3360 \
-- python3 main.py
