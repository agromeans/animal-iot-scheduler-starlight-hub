from flask import Flask, request, jsonify
import requests
import config
import argparse
import lib.scheduler_opt as scheduler_opt
from lib.logger_opt import logger
from lib.exception_opt import ExceptionCommon
from threading import Thread
import time

app = Flask(__name__)
requests.packages.urllib3.disable_warnings()

@app.before_request
def before_request():
    # logger.info("'{path}' start serving remote ip: {ip}".format(path=request.path, ip=request.remote_addr))
    pass
    
@app.route("/version")
def get_version():
    return config.version
    
@app.errorhandler(ExceptionCommon)
def handle_invalid_usage(error):
    response = jsonify(error.to_dict())
    response.status_code = error.status_code
    return response
    
@app.errorhandler(404)
def page_not_found(error):
    response = dict(status_code=404, message="404 Not Found")
    return jsonify(response), 404
    
@app.errorhandler(500)
def handle_500(error):
    response = dict(status_code=500, message="500 Error")
    return jsonify(response), 500
    
if __name__ == "__main__":
    config.reload_config()
    
    parse = argparse.ArgumentParser()
    parse.add_argument('-v', '--version', action='version', version=config.get_version(), help='Display version')
    parse.parse_args()
    
    logger.info('====The program is starting====')
    
    def task():
        time.sleep(3)
        scheduler_opt.run()
        
    taskmgr = Thread(target=task, daemon=True)
    taskmgr.start()
    
    app.run(host='0.0.0.0', port=1880, threaded=True)
    