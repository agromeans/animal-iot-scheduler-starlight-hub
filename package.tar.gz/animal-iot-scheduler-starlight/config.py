from configparser import ConfigParser
from lib.logger_opt import *

config_file = './config.ini'
config = ConfigParser()
config.read(config_file)

version = ''

api_yield_service_capture_weight = ''
api_sensor_service_get_all_sensor = ''

param_scheduler_trigger_interval = None

def get_version():
    return version
    
def check_config_section():
    if not config.has_section('common'):
        config.add_section('common')
        
    if not config.has_section('api'):
        config.add_section('api')
        
    if not config.has_section('param'):
        config.add_section('param')
        
    config.write(open(config_file, 'w'))
    
def get_config():
    global version, api_yield_service_capture_weight, api_sensor_service_get_all_sensor, param_scheduler_trigger_interval
    
    try:
        version = config.get('common', 'version')
    except Exception as e:
        logger.warning(e)
        version = ''
        
    try:
        api_yield_service_capture_weight = config.get('api', 'yield_service_capture_weight')
    except Exception as e:
        logger.warning(e)
        api_yield_service_capture_weight = ''
        
    try:
        api_sensor_service_get_all_sensor = config.get('api', 'sensor_service_get_all_sensor')
    except Exception as e:
        logger.warning(e)
        api_sensor_service_get_all_sensor = ''
        
    try:
        param_scheduler_trigger_interval = int(config.get('param', 'scheduler_trigger_interval'))
    except Exception as e:
        logger.warning(e)
        param_scheduler_trigger_interval = 3
        
def reload_config():
    check_config_section()
    get_config()
    